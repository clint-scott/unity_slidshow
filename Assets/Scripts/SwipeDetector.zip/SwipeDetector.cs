﻿using System;
using UnityEngine;

public class SwipeDetector : MonoBehaviour {
    private Vector2 fingerDownPosition, fingerUpPosition;
	[SerializeField]
	private bool detectSwipeOnlyAfterRelease = false;
	[SerializeField]

	private float minDistanceForSwipe =  20f;

	public static event Action<SwipeData> OnSwipe = delegate { };

	 // Update is called once per frame
    private void Update() {
        foreach(Touch touch in Input.touches) {
			if(touch.phase == TouchPhase.Began) {
				fingerUpPosition = touch.position;
				fingerDownPosition = touch.position;
			}
			if(!detectSwipeOnlyAfterRelease && touch.phase == TouchPhase.Moved) {
				fingerDownPosition = touch.position;
				DetectSwipe();
			}
			if(touch.phase == TouchPhase.Ended) {
				fingerDownPosition = touch.position;
				DetectSwipe();
			}
		}
    }
	
	public void SendSwipe(SwipeDirection direction) {
		SwipeData swipeData = new SwipeData() {
			Direction = direction,
			StartPosition = fingerDownPosition,
			EndPosition = fingerUpPosition
		};
		OnSwipe(swipeData);
	}

	public struct SwipeData {
		public Vector2 StartPosition, EndPosition;
		public SwipeDirection Direction;
	}

	public enum SwipeDirection {
		Up, Right, Down, Left
	}

	private void DetectSwipe() {
		if(SwipeDistanceCheckMet()) {
			if(IsVerticalSwipe()) {
				var direction = fingerDownPosition.y - fingerUpPosition.y > 0 ? SwipeDirection.Up : SwipeDirection.Down;
			}
			else {
				var direction = fingerDownPosition.x - fingerUpPosition.x > 0 ? SwipeDirection.Right : SwipeDirection.Left;
			}
			fingerUpPosition = fingerDownPosition;
		}
	}
	private bool SwipeDistanceCheckMet() {
		return VerticalMoveDistance() > minDistanceForSwipe || HorizontalMoveDistance() > minDistanceForSwipe;
	}
	private bool IsVerticalSwipe() {
		return VerticalMoveDistance() > HorizontalMoveDistance();
	}
	private float VerticalMoveDistance() {
		return Mathf.Abs(fingerDownPosition.y - fingerUpPosition.y);
	}
	private float HorizontalMoveDistance() {
		return Mathf.Abs(fingerDownPosition.x - fingerUpPosition.x);
	}
}
