﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Video;
using DentedPixel;

public class UIManager : MonoBehaviour
{
	public RectTransform MainMenu, Menu_1, Menu_2, Menu_3, Menu_4, Menu_5, Menu_6;
	public GameObject Video_1, Video_2, Video_3, Video_4, Video_5, Video_6;
	private int activeMenu = 0;

    // Start is called before the first frame update
    void Start()  {
        //LeanTween.move( Menu_1, new Vector2(-1920,1080), 0.25f).setEase( LeanTweenType.easeInQuad ).setDelay(0.25f);
		Debug.Log("isPlaying: "+Video_1.gameObject.GetComponent<VideoPlayer> ().source);
		
		Video_1.gameObject.GetComponent<VideoPlayer> ().playOnAwake = false;
		Video_1.gameObject.GetComponent<VideoPlayer> ().Pause();
		Video_1.gameObject.GetComponent<VideoPlayer> ().frame = 0;
		
		Video_2.gameObject.GetComponent<VideoPlayer> ().playOnAwake = false;
		Video_2.gameObject.GetComponent<VideoPlayer> ().Pause();
		Video_2.gameObject.GetComponent<VideoPlayer> ().frame = 0;
		
		Video_3.gameObject.GetComponent<VideoPlayer> ().playOnAwake = false;
		Video_3.gameObject.GetComponent<VideoPlayer> ().Pause();
		Video_3.gameObject.GetComponent<VideoPlayer> ().frame = 0;
		
		Video_4.gameObject.GetComponent<VideoPlayer> ().playOnAwake = false;
		Video_4.gameObject.GetComponent<VideoPlayer> ().Pause();
		Video_4.gameObject.GetComponent<VideoPlayer> ().frame = 0;
		
		Video_5.gameObject.GetComponent<VideoPlayer> ().playOnAwake = false;
		Video_5.gameObject.GetComponent<VideoPlayer> ().Pause();
		Video_5.gameObject.GetComponent<VideoPlayer> ().frame = 0;
		
		Video_6.gameObject.GetComponent<VideoPlayer> ().playOnAwake = false;
		Video_6.gameObject.GetComponent<VideoPlayer> ().Pause();
		Video_6.gameObject.GetComponent<VideoPlayer> ().frame = 0;
    }
	private void playVideo() {

		Debug.Log("*** playVideo ***");

		switch (activeMenu) {
			case 1:
				Video_1.GetComponent<VideoPlayer> ().Play();
				Video_1.GetComponent<VideoPlayer> ().loopPointReached += EndReached;
			break;
			case 2:
				Video_2.GetComponent<VideoPlayer> ().Play();
				Video_2.GetComponent<VideoPlayer> ().loopPointReached += EndReached;
			break;
			case 3:
				Video_3.GetComponent<VideoPlayer> ().Play();
				Video_3.GetComponent<VideoPlayer> ().loopPointReached += EndReached;
			break;
			case 4:
				Video_4.GetComponent<VideoPlayer> ().Play();
				Video_4.GetComponent<VideoPlayer> ().loopPointReached += EndReached;
			break;
			case 5:
				Video_5.GetComponent<VideoPlayer> ().Play();
				Video_5.GetComponent<VideoPlayer> ().loopPointReached += EndReached;
			break;
			case 6:
				Video_6.GetComponent<VideoPlayer> ().Play();
				Video_6.GetComponent<VideoPlayer> ().loopPointReached += EndReached;
			break;
		}
		
	}

	public void EndReached (UnityEngine.Video.VideoPlayer vp) {
		closeMenu();
	}

    public void openMenu(int menuIndex) {
		float delay = activeMenu > 0 ? 1.25f : 0;
		
		if(activeMenu > 0) {
			closeMenu();
		}
		
		activeMenu = menuIndex;
		Debug.Log("Opening menu: "+menuIndex);

		switch (menuIndex) {
			case 1:
				LeanTween.move( Menu_1, new Vector2(1,0), 0.25f).setEase( LeanTweenType.easeInQuad ).setDelay(delay).setOnComplete(playVideo);
			break;
			case 2:
				LeanTween.move( Menu_2, new Vector2(0,1), 0.25f).setEase( LeanTweenType.easeInQuad ).setDelay(delay).setOnComplete(playVideo);
			break;
			case 3:
				LeanTween.move( Menu_3, new Vector2(-1,0), 0.25f).setEase( LeanTweenType.easeInQuad ).setDelay(delay).setOnComplete(playVideo);
			break;
			case 4:
				LeanTween.move( Menu_4, new Vector2(0,-1), 0.25f).setEase( LeanTweenType.easeInQuad ).setDelay(delay).setOnComplete(playVideo);
			break;
			case 5:
				LeanTween.move( Menu_5, new Vector2(1,0), 0.25f).setEase( LeanTweenType.easeInQuad ).setDelay(delay).setOnComplete(playVideo);
			break;
			case 6:
				LeanTween.move( Menu_6, new Vector2(0,1), 0.25f).setEase( LeanTweenType.easeInQuad ).setDelay(delay).setOnComplete(playVideo);
			break;
		}
	}

    public void closeMenu() {
		switch (activeMenu) {
			case 1:
				Video_1.gameObject.GetComponent<VideoPlayer> ().Pause();
				Video_1.gameObject.GetComponent<VideoPlayer> ().frame = 0;
				LeanTween.move( Menu_1, new Vector2(-1,0), 0.25f).setEase( LeanTweenType.easeInQuad );
		Debug.Log("Closing menu: "+activeMenu);
			break;
			case 2:
				Video_2.gameObject.GetComponent<VideoPlayer> ().Pause();
				Video_2.gameObject.GetComponent<VideoPlayer> ().frame = 0;
				LeanTween.move( Menu_2, new Vector2(0,-1), 0.25f).setEase( LeanTweenType.easeInQuad );
		Debug.Log("Closing menu: "+activeMenu);
			break;
			case 3:
				Video_3.gameObject.GetComponent<VideoPlayer> ().Pause();
				Video_3.gameObject.GetComponent<VideoPlayer> ().frame = 0;
				LeanTween.move( Menu_3, new Vector2(1,0), 0.25f).setEase( LeanTweenType.easeInQuad );
		Debug.Log("Closing menu: "+activeMenu);
			break;
			case 4:
				Video_4.gameObject.GetComponent<VideoPlayer> ().Pause();
				Video_4.gameObject.GetComponent<VideoPlayer> ().frame = 0;
				LeanTween.move( Menu_4, new Vector2(0,1), 0.25f).setEase( LeanTweenType.easeInQuad );
		Debug.Log("Closing menu: "+activeMenu);
			break;
			case 5:
				Video_5.gameObject.GetComponent<VideoPlayer> ().Pause();
				Video_5.gameObject.GetComponent<VideoPlayer> ().frame = 0;
				LeanTween.move( Menu_5, new Vector2(-1,0), 0.25f).setEase( LeanTweenType.easeInQuad );
		Debug.Log("Closing menu: "+activeMenu);
			break;
			case 6:
				Video_6.gameObject.GetComponent<VideoPlayer> ().Pause();
				Video_6.gameObject.GetComponent<VideoPlayer> ().frame = 0;
				LeanTween.move( Menu_6, new Vector2(0,-1), 0.25f).setEase( LeanTweenType.easeInQuad );
		Debug.Log("Closing menu: "+activeMenu);
			break;
		}
		activeMenu = 0;
	}
}
